from pathlib import Path
path = Path(r"c:/Escritorio/Proyecto_TC/capstone/management/views.py")
text = path.read_text(encoding='utf-8')
start = text.index("def _company_info():")
end = text.index("def _build_absolute_url", start)
new_block = """LOGO_CID = \"logo-horizontal\"\nLOGO_PATH = Path(settings.BASE_DIR) / \"main\" / \"static\" / \"images\" / \"logo-horizontal.png\"\n_LOGO_INLINE_DATA = None\n\n\ndef _company_info():\n\n    return {\n\n        \"nombre\": getattr(settings, \"TALLER_NOMBRE\", \"TallerConnect\"),\n\n        \"rut\": getattr(settings, \"TALLER_RUT\", \"99.999.999-9\"),\n\n        \"telefono\": getattr(settings, \"TALLER_TELEFONO\", \"+56 9 0000 0000\"),\n\n        \"email\": getattr(settings, \"DEFAULT_FROM_EMAIL\", \"contacto@example.com\"),\n\n        \"direccion\": getattr(settings, \"TALLER_DIRECCION\", \"Puente Alto, Chile\"),\n\n        \"giro\": getattr(settings, \"TALLER_GIRO\", \"\"),\n\n        \"actividad\": getattr(settings, \"TALLER_ACTIVIDAD\", \"\"),\n\n        \"url\": getattr(\n\n            settings,\n\n            \"TALLER_CUENTA_URL\",\n\n            getattr(settings, \"SITE_BASE_URL\", \"https://www.tallerconnect.cl\"),\n\n        ),\n\n    }\n\n"""
new_block = new_block.replace("\n", "\r\n")
text = text[:start] + new_block + text[end:]
path.write_text(text, encoding='utf-8')
