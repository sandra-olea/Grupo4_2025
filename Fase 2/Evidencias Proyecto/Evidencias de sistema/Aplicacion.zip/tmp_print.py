from pathlib import Path
path = Path(r'c:/Escritorio/Proyecto_TC/capstone/management/views.py')
with path.open(encoding='utf-8') as f:
    lines = f.readlines()
for i in range(420,470):
    print(i+1, lines[i].rstrip())

