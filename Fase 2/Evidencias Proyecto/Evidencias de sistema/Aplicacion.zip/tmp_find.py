from pathlib import Path
path = Path(r'c:/Escritorio/Proyecto_TC/capstone/management/views.py')
with path.open(encoding='utf-8') as f:
    lines = f.readlines()
for idx,line in enumerate(lines,1):
    if 'def _attach_logo_inline' in line:
        print(idx)

