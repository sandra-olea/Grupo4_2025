-- --------------------------------------------------------
-- Host:                         database-tallerconnect.c69o0ciacj36.us-east-1.rds.amazonaws.com
-- Versión del servidor:         8.0.42 - Source distribution
-- SO del servidor:              Linux
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla db_tallerconnect.auth_group
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.auth_group_permissions
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.auth_permission
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.django_admin_log
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_main_customuser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_main_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `main_customuser` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.django_content_type
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.django_migrations
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.django_session
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_cliente
CREATE TABLE IF NOT EXISTS `main_cliente` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido_paterno` varchar(100) NOT NULL,
  `apellido_materno` varchar(100) NOT NULL,
  `rut` varchar(12) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` char(1) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `user_id` bigint NOT NULL,
  `comuna_id` bigint DEFAULT NULL,
  `region_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rut` (`rut`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `main_cliente_comuna_id_e4e439db_fk_main_comuna_id` (`comuna_id`),
  KEY `main_cliente_region_id_24614274_fk_main_region_id` (`region_id`),
  CONSTRAINT `main_cliente_comuna_id_e4e439db_fk_main_comuna_id` FOREIGN KEY (`comuna_id`) REFERENCES `main_comuna` (`id`),
  CONSTRAINT `main_cliente_region_id_24614274_fk_main_region_id` FOREIGN KEY (`region_id`) REFERENCES `main_region` (`id`),
  CONSTRAINT `main_cliente_user_id_8b458635_fk_main_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `main_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_comuna
CREATE TABLE IF NOT EXISTS `main_comuna` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `region_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `main_comuna_region_id_bf796365_fk_main_region_id` (`region_id`),
  CONSTRAINT `main_comuna_region_id_bf796365_fk_main_region_id` FOREIGN KEY (`region_id`) REFERENCES `main_region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_customuser
CREATE TABLE IF NOT EXISTS `main_customuser` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `email` varchar(254) NOT NULL,
  `username` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_customuser_groups
CREATE TABLE IF NOT EXISTS `main_customuser_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `main_customuser_groups_customuser_id_group_id_8a5023dd_uniq` (`customuser_id`,`group_id`),
  KEY `main_customuser_groups_group_id_8149f607_fk_auth_group_id` (`group_id`),
  CONSTRAINT `main_customuser_grou_customuser_id_13869e25_fk_main_cust` FOREIGN KEY (`customuser_id`) REFERENCES `main_customuser` (`id`),
  CONSTRAINT `main_customuser_groups_group_id_8149f607_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_customuser_user_permissions
CREATE TABLE IF NOT EXISTS `main_customuser_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `main_customuser_user_per_customuser_id_permission_06a652d8_uniq` (`customuser_id`,`permission_id`),
  KEY `main_customuser_user_permission_id_38e6f657_fk_auth_perm` (`permission_id`),
  CONSTRAINT `main_customuser_user_customuser_id_34d37f86_fk_main_cust` FOREIGN KEY (`customuser_id`) REFERENCES `main_customuser` (`id`),
  CONSTRAINT `main_customuser_user_permission_id_38e6f657_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_personal
CREATE TABLE IF NOT EXISTS `main_personal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido_paterno` varchar(100) NOT NULL,
  `apellido_materno` varchar(100) NOT NULL,
  `rut` varchar(12) NOT NULL,
  `genero` varchar(10) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `especialidad` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `comuna_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `region_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rut` (`rut`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `main_personal_comuna_id_c7649724_fk_main_comuna_id` (`comuna_id`),
  KEY `main_personal_region_id_d4dd23f8_fk_main_region_id` (`region_id`),
  CONSTRAINT `main_personal_comuna_id_c7649724_fk_main_comuna_id` FOREIGN KEY (`comuna_id`) REFERENCES `main_comuna` (`id`),
  CONSTRAINT `main_personal_region_id_d4dd23f8_fk_main_region_id` FOREIGN KEY (`region_id`) REFERENCES `main_region` (`id`),
  CONSTRAINT `main_personal_user_id_f6f5e43f_fk_main_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `main_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_region
CREATE TABLE IF NOT EXISTS `main_region` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.main_vehiculo
CREATE TABLE IF NOT EXISTS `main_vehiculo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `patente` varchar(10) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `anio` int unsigned DEFAULT NULL,
  `engine_number` varchar(50) DEFAULT NULL,
  `vin` varchar(50) DEFAULT NULL,
  `kilometraje` int unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `owner_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patente` (`patente`),
  KEY `main_vehiculo_owner_id_cc204c05_fk_main_customuser_id` (`owner_id`),
  CONSTRAINT `main_vehiculo_owner_id_cc204c05_fk_main_customuser_id` FOREIGN KEY (`owner_id`) REFERENCES `main_customuser` (`id`),
  CONSTRAINT `main_vehiculo_chk_1` CHECK ((`anio` >= 0)),
  CONSTRAINT `main_vehiculo_chk_2` CHECK ((`kilometraje` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_boleta
CREATE TABLE IF NOT EXISTS `management_boleta` (
  `documentocomercial_ptr_id` bigint NOT NULL,
  PRIMARY KEY (`documentocomercial_ptr_id`),
  CONSTRAINT `management_boleta_documentocomercial_p_a42bce27_fk_managemen` FOREIGN KEY (`documentocomercial_ptr_id`) REFERENCES `management_documentocomercial` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_cargo
CREATE TABLE IF NOT EXISTS `management_cargo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `creado_en` datetime(6) NOT NULL,
  `actualizado_en` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_cotizacion
CREATE TABLE IF NOT EXISTS `management_cotizacion` (
  `documentocomercial_ptr_id` bigint NOT NULL,
  PRIMARY KEY (`documentocomercial_ptr_id`),
  CONSTRAINT `management_cotizacio_documentocomercial_p_94755de4_fk_managemen` FOREIGN KEY (`documentocomercial_ptr_id`) REFERENCES `management_documentocomercial` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_detalledocumento
CREATE TABLE IF NOT EXISTS `management_detalledocumento` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tipo_item` varchar(15) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `cantidad` int unsigned NOT NULL,
  `costo_unitario` int unsigned NOT NULL,
  `precio_unitario` int unsigned NOT NULL,
  `total_costo` int unsigned NOT NULL,
  `total_venta` int unsigned NOT NULL,
  `mostrar_en_documento` tinyint(1) NOT NULL,
  `documento_id` bigint NOT NULL,
  `servicio_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `management_documento_documento_id_9c20aeda_fk_managemen` (`documento_id`),
  KEY `management_documento_servicio_id_036cf31a_fk_managemen` (`servicio_id`),
  CONSTRAINT `management_documento_documento_id_9c20aeda_fk_managemen` FOREIGN KEY (`documento_id`) REFERENCES `management_documentocomercial` (`id`),
  CONSTRAINT `management_documento_servicio_id_036cf31a_fk_managemen` FOREIGN KEY (`servicio_id`) REFERENCES `management_servicio` (`id`),
  CONSTRAINT `management_documentoitem_cantidad_d7ab8807_check` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `management_documentoitem_costo_unitario_a2e49e9d_check` CHECK ((`costo_unitario` >= 0)),
  CONSTRAINT `management_documentoitem_precio_unitario_aa555859_check` CHECK ((`precio_unitario` >= 0)),
  CONSTRAINT `management_documentoitem_total_costo_eeab2394_check` CHECK ((`total_costo` >= 0)),
  CONSTRAINT `management_documentoitem_total_venta_9c4cdb52_check` CHECK ((`total_venta` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=509 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_documentocomercial
CREATE TABLE IF NOT EXISTS `management_documentocomercial` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tipo` varchar(15) NOT NULL,
  `estado` varchar(15) NOT NULL,
  `numero` varchar(30) NOT NULL,
  `fecha_emision` date NOT NULL,
  `validez_hasta` date DEFAULT NULL,
  `forma_pago` varchar(100) NOT NULL,
  `observaciones` longtext NOT NULL,
  `condiciones` longtext NOT NULL,
  `cliente_nombre` varchar(150) NOT NULL,
  `cliente_rut` varchar(20) NOT NULL,
  `cliente_email` varchar(254) NOT NULL,
  `cliente_direccion` varchar(255) NOT NULL,
  `cliente_ciudad` varchar(100) NOT NULL,
  `subtotal_servicios` decimal(12,2) NOT NULL,
  `subtotal_repuestos` decimal(12,2) NOT NULL,
  `mano_obra` decimal(12,2) NOT NULL,
  `otros_cargos` decimal(12,2) NOT NULL,
  `descuento_total` int unsigned NOT NULL,
  `iva` decimal(12,2) NOT NULL,
  `total_general` decimal(12,2) NOT NULL,
  `total_costo` decimal(12,2) NOT NULL,
  `enviado_por_correo` tinyint(1) NOT NULL,
  `enviado_en` datetime(6) DEFAULT NULL,
  `creado_por_id` bigint DEFAULT NULL,
  `orden_id` bigint NOT NULL,
  `documento_origen_id` bigint DEFAULT NULL,
  `cliente_telefono` varchar(30) NOT NULL,
  `cliente_giro` varchar(150) NOT NULL DEFAULT '',
  `factura_condiciones_pago` varchar(255) NOT NULL DEFAULT '',
  `factura_emisor_actividad` varchar(255) NOT NULL DEFAULT '',
  `factura_emisor_ciudad` varchar(100) NOT NULL DEFAULT '',
  `factura_emisor_comuna` varchar(100) NOT NULL DEFAULT '',
  `factura_emisor_direccion` varchar(255) NOT NULL DEFAULT '',
  `factura_emisor_email` varchar(254) NOT NULL DEFAULT '',
  `factura_emisor_giro` varchar(255) NOT NULL DEFAULT '',
  `factura_emisor_razon_social` varchar(255) NOT NULL DEFAULT '',
  `factura_emisor_rut` varchar(20) NOT NULL DEFAULT '',
  `factura_emisor_telefono` varchar(50) NOT NULL DEFAULT '',
  `cliente_apellido_paterno` varchar(150) NOT NULL,
  `vehiculo_marca` varchar(100) NOT NULL,
  `vehiculo_modelo` varchar(100) NOT NULL,
  `vehiculo_patente` varchar(30) NOT NULL,
  `medio_pago` varchar(20) NOT NULL,
  `cliente_id` bigint DEFAULT NULL,
  `vehiculo_id` bigint DEFAULT NULL,
  `snapshot_cliente` json NOT NULL DEFAULT (_utf8mb4'{}'),
  `snapshot_vehiculo` json NOT NULL DEFAULT (_utf8mb4'{}'),
  PRIMARY KEY (`id`),
  KEY `management_documento_creado_por_id_d6721615_fk_main_cust` (`creado_por_id`),
  KEY `management_documento_orden_id_4f72d788_fk_managemen` (`orden_id`),
  KEY `management_documento_documento_origen_id_3e8d19b9_fk_managemen` (`documento_origen_id`),
  KEY `management_documento_cliente_id_18ca8512_fk_main_clie` (`cliente_id`),
  KEY `management_documento_vehiculo_id_4c46ad91_fk_main_vehi` (`vehiculo_id`),
  CONSTRAINT `management_documento_cliente_id_18ca8512_fk_main_clie` FOREIGN KEY (`cliente_id`) REFERENCES `main_cliente` (`id`),
  CONSTRAINT `management_documento_creado_por_id_d6721615_fk_main_cust` FOREIGN KEY (`creado_por_id`) REFERENCES `main_customuser` (`id`),
  CONSTRAINT `management_documento_documento_origen_id_3e8d19b9_fk_managemen` FOREIGN KEY (`documento_origen_id`) REFERENCES `management_documentocomercial` (`id`),
  CONSTRAINT `management_documento_orden_id_4f72d788_fk_managemen` FOREIGN KEY (`orden_id`) REFERENCES `management_ordendetrabajo` (`id`),
  CONSTRAINT `management_documento_vehiculo_id_4c46ad91_fk_main_vehi` FOREIGN KEY (`vehiculo_id`) REFERENCES `main_vehiculo` (`id`),
  CONSTRAINT `management_documentocomercial_descuento_total_055eab9f_check` CHECK ((`descuento_total` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_especialidad
CREATE TABLE IF NOT EXISTS `management_especialidad` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `creado_en` datetime(6) NOT NULL,
  `actualizado_en` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_evidenciaatencion
CREATE TABLE IF NOT EXISTS `management_evidenciaatencion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `imagen` varchar(100) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `recepcion_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `management_evidencia_recepcion_id_4f093c22_fk_managemen` (`recepcion_id`),
  CONSTRAINT `management_evidencia_recepcion_id_4f093c22_fk_managemen` FOREIGN KEY (`recepcion_id`) REFERENCES `management_ordenrecepcionvehiculo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_factura
CREATE TABLE IF NOT EXISTS `management_factura` (
  `documentocomercial_ptr_id` bigint NOT NULL,
  `factura_emisor_rut` varchar(20) NOT NULL,
  `factura_emisor_razon_social` varchar(255) NOT NULL,
  `factura_emisor_direccion` varchar(255) NOT NULL,
  `factura_emisor_comuna` varchar(100) NOT NULL,
  `factura_emisor_ciudad` varchar(100) NOT NULL,
  `factura_emisor_email` varchar(254) NOT NULL,
  `factura_emisor_telefono` varchar(50) NOT NULL,
  `factura_emisor_giro` varchar(255) NOT NULL,
  `factura_emisor_actividad` varchar(255) NOT NULL,
  `factura_condiciones_pago` varchar(255) NOT NULL,
  PRIMARY KEY (`documentocomercial_ptr_id`),
  CONSTRAINT `management_factura_documentocomercial_p_e8ffd653_fk_managemen` FOREIGN KEY (`documentocomercial_ptr_id`) REFERENCES `management_documentocomercial` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_horariopersonal
CREATE TABLE IF NOT EXISTS `management_horariopersonal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dia_semana` int NOT NULL,
  `hora_entrada` time DEFAULT NULL,
  `hora_salida` time DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `personal_id` bigint NOT NULL,
  `sucursal_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_horario_personal_sucursal_dia` (`sucursal_id`,`personal_id`,`dia_semana`),
  KEY `management_horariopersonal_personal_id_fk` (`personal_id`),
  CONSTRAINT `management_horariopersonal_personal_id_fk` FOREIGN KEY (`personal_id`) REFERENCES `management_personal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `management_horariopersonal_sucursal_id_fk` FOREIGN KEY (`sucursal_id`) REFERENCES `management_sucursal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_horariosucursal
CREATE TABLE IF NOT EXISTS `management_horariosucursal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dia_semana` int NOT NULL,
  `hora_apertura` time(6) DEFAULT NULL,
  `hora_cierre` time(6) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `sucursal_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_horario_sucursal_dia` (`sucursal_id`,`dia_semana`),
  KEY `management_horariosucursal_sucursal_id_051bf305` (`sucursal_id`),
  CONSTRAINT `management_horariosu_sucursal_id_051bf305_fk_managemen` FOREIGN KEY (`sucursal_id`) REFERENCES `management_sucursal` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_ordendetrabajo
CREATE TABLE IF NOT EXISTS `management_ordendetrabajo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_hora_cita` datetime(6) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  `estado` varchar(40) NOT NULL,
  `cliente_id` bigint NOT NULL,
  `mecanico_asignado_id` bigint DEFAULT NULL,
  `vehiculo_id` bigint NOT NULL,
  `sucursal_id` bigint DEFAULT NULL,
  `tipo_servicio` varchar(20) NOT NULL,
  `recordatorio_enviado_en` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `management_ordendetr_sucursal_id_e47735ce_fk_managemen` (`sucursal_id`),
  KEY `management_ordendetrabajo_cliente_id_139b0efb_fk_main_cliente_id` (`cliente_id`),
  KEY `management_ordendetr_vehiculo_id_8962a588_fk_main_vehi` (`vehiculo_id`),
  KEY `management_ordendetr_mecanico_asignado_id_fk` (`mecanico_asignado_id`),
  CONSTRAINT `management_ordendetr_mecanico_asignado_id_fk` FOREIGN KEY (`mecanico_asignado_id`) REFERENCES `management_personal` (`id`) ON DELETE SET NULL,
  CONSTRAINT `management_ordendetr_sucursal_id_e47735ce_fk_managemen` FOREIGN KEY (`sucursal_id`) REFERENCES `management_sucursal` (`id`),
  CONSTRAINT `management_ordendetr_vehiculo_id_8962a588_fk_main_vehi` FOREIGN KEY (`vehiculo_id`) REFERENCES `main_vehiculo` (`id`),
  CONSTRAINT `management_ordendetrabajo_cliente_id_139b0efb_fk_main_cliente_id` FOREIGN KEY (`cliente_id`) REFERENCES `main_cliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_ordendetrabajo_servicios_solicitados
CREATE TABLE IF NOT EXISTS `management_ordendetrabajo_servicios_solicitados` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ordendetrabajo_id` bigint NOT NULL,
  `servicio_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `management_ordendetrabaj_ordendetrabajo_id_servic_6cbdf986_uniq` (`ordendetrabajo_id`,`servicio_id`),
  KEY `management_ordendetr_servicio_id_c7f5ade2_fk_managemen` (`servicio_id`),
  CONSTRAINT `management_ordendetr_ordendetrabajo_id_e0bd1008_fk_managemen` FOREIGN KEY (`ordendetrabajo_id`) REFERENCES `management_ordendetrabajo` (`id`),
  CONSTRAINT `management_ordendetr_servicio_id_c7f5ade2_fk_managemen` FOREIGN KEY (`servicio_id`) REFERENCES `management_servicio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_ordenrecepcionvehiculo
CREATE TABLE IF NOT EXISTS `management_ordenrecepcionvehiculo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `folio` int unsigned NOT NULL,
  `fecha_ingreso` datetime(6) DEFAULT NULL,
  `fecha_salida` datetime(6) DEFAULT NULL,
  `ingreso_grua` varchar(2) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `anio` varchar(10) NOT NULL,
  `patente` varchar(20) NOT NULL,
  `kilometraje` int unsigned DEFAULT NULL,
  `vin` varchar(50) NOT NULL,
  `engine_number` varchar(50) NOT NULL,
  `trabajo_a_realizar` longtext NOT NULL,
  `observaciones` longtext NOT NULL,
  `combustible_nivel` json DEFAULT NULL,
  `icon_cinturon` tinyint(1) NOT NULL,
  `icon_airbag` tinyint(1) NOT NULL,
  `icon_abs` tinyint(1) NOT NULL,
  `icon_aceite` tinyint(1) NOT NULL,
  `icon_bateria` tinyint(1) NOT NULL,
  `icon_motor` tinyint(1) NOT NULL,
  `icon_direccion` tinyint(1) NOT NULL,
  `icon_freno_mano` tinyint(1) NOT NULL,
  `icon_luces` tinyint(1) NOT NULL,
  `icon_suspension` tinyint(1) NOT NULL,
  `inv_gato` tinyint(1) NOT NULL,
  `inv_herramientas` tinyint(1) NOT NULL,
  `inv_triangulos` tinyint(1) NOT NULL,
  `inv_tapetes` tinyint(1) NOT NULL,
  `inv_llanta_refaccion` tinyint(1) NOT NULL,
  `inv_extintor` tinyint(1) NOT NULL,
  `inv_antena` tinyint(1) NOT NULL,
  `inv_emblemas` tinyint(1) NOT NULL,
  `inv_tapones_rueda` tinyint(1) NOT NULL,
  `inv_cables` tinyint(1) NOT NULL,
  `inv_estereo` tinyint(1) NOT NULL,
  `inv_encendedor` tinyint(1) NOT NULL,
  `danos_lado_derecho` json NOT NULL,
  `danos_lado_izquierdo` json NOT NULL,
  `danos_frente` json NOT NULL,
  `danos_trasero` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `orden_id` bigint NOT NULL,
  `atencion_inicio` datetime(6) DEFAULT NULL,
  `atencion_fin` datetime(6) DEFAULT NULL,
  `atencion_reanudacion_actual` datetime(6) DEFAULT NULL,
  `atencion_segundos_acumulados` int unsigned NOT NULL,
  `detalles_servicio` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folio` (`folio`),
  UNIQUE KEY `orden_id` (`orden_id`),
  CONSTRAINT `management_ordenrece_orden_id_dba4a2c3_fk_managemen` FOREIGN KEY (`orden_id`) REFERENCES `management_ordendetrabajo` (`id`),
  CONSTRAINT `management_ordenrecepcionvehiculo_chk_1` CHECK ((`folio` >= 0)),
  CONSTRAINT `management_ordenrecepcionvehiculo_chk_2` CHECK ((`kilometraje` >= 0)),
  CONSTRAINT `management_ordenrecepcionvehiculo_chk_3` CHECK ((`atencion_segundos_acumulados` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_ordenrecepcionvehiculo_servicios_realizados
CREATE TABLE IF NOT EXISTS `management_ordenrecepcionvehiculo_servicios_realizados` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ordenrecepcionvehiculo_id` bigint NOT NULL,
  `servicio_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `management_ordenrecepcio_ordenrecepcionvehiculo_i_b4a8cf4e_uniq` (`ordenrecepcionvehiculo_id`,`servicio_id`),
  KEY `management_ordenrece_servicio_id_0fd55ae6_fk_managemen` (`servicio_id`),
  CONSTRAINT `management_ordenrece_ordenrecepcionvehicu_4b77f457_fk_managemen` FOREIGN KEY (`ordenrecepcionvehiculo_id`) REFERENCES `management_ordenrecepcionvehiculo` (`id`),
  CONSTRAINT `management_ordenrece_servicio_id_0fd55ae6_fk_managemen` FOREIGN KEY (`servicio_id`) REFERENCES `management_servicio` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_personal
CREATE TABLE IF NOT EXISTS `management_personal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido_paterno` varchar(100) NOT NULL,
  `apellido_materno` varchar(100) NOT NULL,
  `rut` varchar(12) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('M','F','O') NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `comuna_id` bigint DEFAULT NULL,
  `region_id` bigint DEFAULT NULL,
  `sucursal_id` bigint DEFAULT NULL,
  `usuario_id` bigint NOT NULL,
  `cargo_id` bigint DEFAULT NULL,
  `especialidad_id` bigint DEFAULT NULL,
  `es_admin_sucursal` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rut` (`rut`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  KEY `management_personal_comuna_id_72a6d8a3_fk_main_comuna_id` (`comuna_id`),
  KEY `management_personal_region_id_29af359d_fk_main_region_id` (`region_id`),
  KEY `management_personal_sucursal_id_d468db05_fk_managemen` (`sucursal_id`),
  KEY `management_personal_cargo_id_83280c68_fk_management_cargo_id` (`cargo_id`),
  KEY `management_personal_especialidad_id_6d87ef51_fk_managemen` (`especialidad_id`),
  CONSTRAINT `management_personal_cargo_id_83280c68_fk_management_cargo_id` FOREIGN KEY (`cargo_id`) REFERENCES `management_cargo` (`id`),
  CONSTRAINT `management_personal_comuna_id_72a6d8a3_fk_main_comuna_id` FOREIGN KEY (`comuna_id`) REFERENCES `main_comuna` (`id`),
  CONSTRAINT `management_personal_especialidad_id_6d87ef51_fk_managemen` FOREIGN KEY (`especialidad_id`) REFERENCES `management_especialidad` (`id`),
  CONSTRAINT `management_personal_region_id_29af359d_fk_main_region_id` FOREIGN KEY (`region_id`) REFERENCES `main_region` (`id`),
  CONSTRAINT `management_personal_sucursal_id_d468db05_fk_managemen` FOREIGN KEY (`sucursal_id`) REFERENCES `management_sucursal` (`id`),
  CONSTRAINT `management_personal_usuario_id_0cb9c24a_fk_main_customuser_id` FOREIGN KEY (`usuario_id`) REFERENCES `main_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_servicio
CREATE TABLE IF NOT EXISTS `management_servicio` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` longtext NOT NULL,
  `duracion_minutos` int unsigned NOT NULL,
  `precio_base` int unsigned NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  CONSTRAINT `management_servicio_chk_1` CHECK ((`duracion_minutos` >= 0)),
  CONSTRAINT `management_servicio_chk_2` CHECK ((`precio_base` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_servicioporsucursal
CREATE TABLE IF NOT EXISTS `management_servicioporsucursal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `precio_sucursal` int unsigned NOT NULL,
  `disponible` tinyint(1) NOT NULL,
  `servicio_id` bigint NOT NULL,
  `sucursal_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `management_servicioporsu_servicio_id_sucursal_id_1e84abba_uniq` (`servicio_id`,`sucursal_id`),
  KEY `management_serviciop_sucursal_id_13fd4f5b_fk_managemen` (`sucursal_id`),
  CONSTRAINT `management_serviciop_servicio_id_a3655966_fk_managemen` FOREIGN KEY (`servicio_id`) REFERENCES `management_servicio` (`id`),
  CONSTRAINT `management_serviciop_sucursal_id_13fd4f5b_fk_managemen` FOREIGN KEY (`sucursal_id`) REFERENCES `management_sucursal` (`id`),
  CONSTRAINT `management_servicioporsucursal_chk_1` CHECK ((`precio_sucursal` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_servicio_personal_calificado
CREATE TABLE IF NOT EXISTS `management_servicio_personal_calificado` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `servicio_id` bigint NOT NULL,
  `personal_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `management_servicio_pers_servicio_id_personal_id_76688a82_uniq` (`servicio_id`,`personal_id`),
  KEY `management_servicio__personal_id_12c3fd61_fk_managemen` (`personal_id`),
  CONSTRAINT `management_servicio__personal_id_12c3fd61_fk_managemen` FOREIGN KEY (`personal_id`) REFERENCES `management_personal` (`id`),
  CONSTRAINT `management_servicio__servicio_id_3f9bb5f4_fk_managemen` FOREIGN KEY (`servicio_id`) REFERENCES `management_servicio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.management_sucursal
CREATE TABLE IF NOT EXISTS `management_sucursal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `comuna_id` bigint NOT NULL,
  `region_id` bigint NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `management_sucursal_comuna_id_86e2df3d_fk_main_comuna_id` (`comuna_id`),
  KEY `management_sucursal_region_id_ec85eebd_fk_main_region_id` (`region_id`),
  CONSTRAINT `management_sucursal_comuna_id_86e2df3d_fk_main_comuna_id` FOREIGN KEY (`comuna_id`) REFERENCES `main_comuna` (`id`),
  CONSTRAINT `management_sucursal_region_id_ec85eebd_fk_main_region_id` FOREIGN KEY (`region_id`) REFERENCES `main_region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.pretest_child
CREATE TABLE IF NOT EXISTS `pretest_child` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_ref` int DEFAULT NULL,
  `note` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_parent_ref` (`parent_ref`),
  CONSTRAINT `fk_parent_ref` FOREIGN KEY (`parent_ref`) REFERENCES `pretest_tmp` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.pretest_tmp
CREATE TABLE IF NOT EXISTS `pretest_tmp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payload` varchar(64) DEFAULT NULL,
  `ref` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28821 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.pretest_tmp_b
CREATE TABLE IF NOT EXISTS `pretest_tmp_b` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payload` varchar(64) DEFAULT NULL,
  `ref` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.test_ops
CREATE TABLE IF NOT EXISTS `test_ops` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.test_ops_b
CREATE TABLE IF NOT EXISTS `test_ops_b` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla db_tallerconnect.test_ops_child
CREATE TABLE IF NOT EXISTS `test_ops_child` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_parent` (`parent_id`),
  CONSTRAINT `fk_parent` FOREIGN KEY (`parent_id`) REFERENCES `test_ops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- La exportación de datos fue deseleccionada.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
